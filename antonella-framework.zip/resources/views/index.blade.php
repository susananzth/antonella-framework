
@if(1==2)
<div>es verdad</div>
@else
<div>es mentira</div>
@endif