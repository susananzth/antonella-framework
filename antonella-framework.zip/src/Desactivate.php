<?php
namespace CAF;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
