<?php
namespace SU;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
