<?php
namespace PPT;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
