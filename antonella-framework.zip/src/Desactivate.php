<?php
namespace PCF;

class Desactivate
{
    /*
    *
    */
    public function index()
    {

    }
}
