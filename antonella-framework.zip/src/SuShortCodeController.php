<?php
    namespace SU;
          
    class SuShortCodeController
    {
    
        public function __construct()
        {
    
        }
        public function MiShortCode()
        {
            return('Hola Mundo!');
        }
    }