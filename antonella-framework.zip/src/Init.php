<?php
namespace PCF;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {

    }
}
