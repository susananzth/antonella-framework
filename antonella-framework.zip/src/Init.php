<?php
namespace CAF;

class Init
{
    public function __construct()
    {

    }

    public static function index()
    {

    }
}
